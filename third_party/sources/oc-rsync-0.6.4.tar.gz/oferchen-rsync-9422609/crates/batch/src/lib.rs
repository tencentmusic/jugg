#![deny(unsafe_code)]
#![deny(missing_docs)]
#![deny(rustdoc::broken_intra_doc_links)]

//! Batch mode support for offline/disconnected transfer workflows.
//!
//! This crate implements rsync's batch mode functionality, which allows
//! recording a transfer operation to a file and replaying it later. This
//! is useful for scenarios where the source and destination are not
//! simultaneously available, or for distributing the same changes to
//! multiple destinations.
//!
//! # Overview
//!
//! Batch mode enables a "capture and replay" workflow for file transfers:
//!
//! 1. **Capture**: Record a transfer to a batch file (binary) and companion script
//! 2. **Distribute**: Copy the batch file to other machines (USB, network, etc.)
//! 3. **Replay**: Apply the recorded changes to different destinations
//!
//! This pattern is particularly useful for:
//! - Air-gapped systems without direct network connectivity
//! - Distributing identical updates to many machines
//! - Auditing and reviewing changes before applying them
//! - Bandwidth-constrained environments where batch files can be compressed
//!
//! # Batch File Format
//!
//! The batch file format matches upstream rsync's binary format for compatibility.
//! Upstream rsync creates the batch file by teeing (copying) the protocol stream
//! to a file, not by serializing a custom format.
//!
//! 1. **Header** ([`BatchHeader`]):
//!    - Stream flags bitmap (i32) -- `batch.c:write_stream_flags()`
//!    - Protocol version (i32) -- `io.c:start_write_batch()`
//!    - Compat flags (varint, protocol >= 30)
//!    - Checksum seed (i32)
//!
//! 2. **Protocol stream body** (raw tee):
//!    - File list data in standard flist wire format
//!    - Delta operations (copy/literal tokens) for each transferred file
//!    - This is the exact byte stream that would flow over the protocol
//!      connection, captured via `write_batch_monitor_in`/`_out` in `io.c`
//!
//! 3. **Statistics** ([`BatchStats`], at end):
//!    - Total bytes read/written/size (varlong30 with min_bytes=3)
//!    - File list build/transfer time (protocol >= 29)
//!
//! # Shell Script
//!
//! In addition to the binary batch file, a shell script (.sh) is created
//! that contains the replay command. This script:
//! - Converts `--write-batch` to `--read-batch`
//! - Preserves all relevant options
//! - Includes filter rules if present
//!
//! See the [`script`] module for script generation functions.
//!
//! # Command Line Usage
//!
//! ## Writing a batch (with transfer)
//! ```text
//! oc-rsync -a --write-batch=mybatch source/ /tmp/dest/
//! # Creates: mybatch (binary) and mybatch.sh (script)
//! # Also transfers files to /tmp/dest/
//! ```
//!
//! ## Writing a batch (without transfer)
//! ```text
//! oc-rsync -a --only-write-batch=mybatch source/ dest/
//! # Creates batch files but doesn't modify dest/
//! # Useful for creating batches without affecting the destination
//! ```
//!
//! ## Reading/replaying a batch
//! ```text
//! # Using the generated script:
//! ./mybatch.sh /actual/dest/
//!
//! # Or manually:
//! oc-rsync --read-batch=mybatch /actual/dest/
//! ```
//!
//! # Programmatic Usage
//!
//! ## Writing a batch file
//!
//! ```no_run
//! use batch::{BatchConfig, BatchMode, BatchWriter, BatchFlags};
//!
//! // Configure the batch operation
//! let config = BatchConfig::new(
//!     BatchMode::Write,
//!     "/tmp/mybatch".to_string(),
//!     31,  // protocol version
//! )
//! .with_checksum_seed(12345);
//!
//! // Create the writer
//! let mut writer = BatchWriter::new(config)?;
//!
//! // Write the header with stream flags
//! let mut flags = BatchFlags::default();
//! flags.recurse = true;
//! flags.preserve_uid = true;
//! writer.write_header(flags)?;
//!
//! // Write file data (normally done during transfer)
//! writer.write_data(b"file content data")?;
//!
//! // Finalize and close the batch file
//! writer.finalize()?;
//! # Ok::<(), batch::BatchError>(())
//! ```
//!
//! ## Reading a batch file
//!
//! ```no_run
//! use batch::{BatchConfig, BatchMode, BatchReader};
//!
//! // Configure to read the batch
//! let config = BatchConfig::new(
//!     BatchMode::Read,
//!     "/tmp/mybatch".to_string(),
//!     31,  // must match the protocol version used to write
//! );
//!
//! // Open the batch file
//! let mut reader = BatchReader::new(config)?;
//!
//! // Read and validate the header
//! let flags = reader.read_header()?;
//! println!("Batch uses recursive mode: {}", flags.recurse);
//!
//! // Read file data
//! let mut buf = vec![0u8; 1024];
//! let bytes_read = reader.read_data(&mut buf)?;
//! # Ok::<(), batch::BatchError>(())
//! ```
//!
//! # Error Handling
//!
//! All batch operations return [`BatchResult<T>`], which wraps potential
//! [`BatchError`] variants:
//!
//! - [`BatchError::Io`] - File system or I/O errors
//! - [`BatchError::InvalidFormat`] - Malformed or incompatible batch files
//! - [`BatchError::Unsupported`] - Features not yet implemented
//! - [`BatchError::FlagMismatch`] - A batch stream flag cannot be reconciled
//!   with the active options (a fatal `--iconv` mismatch)
//!
//! # Thread Safety
//!
//! [`BatchReader`] and [`BatchWriter`] are not thread-safe and should be
//! used from a single thread. For concurrent batch processing, create
//! separate reader/writer instances for each thread.

mod error;

/// Binary format definitions for batch files.
///
/// This module contains the low-level structures for reading and writing
/// the batch file format: [`BatchHeader`], [`BatchFlags`], and [`FileEntry`].
pub mod format;

/// Batch file reader for replaying recorded transfers.
///
/// See [`BatchReader`] for the main reader type.
pub mod reader;

/// Shell script generation for batch replay.
///
/// This module provides functions to generate executable shell scripts
/// that can replay batch files. See [`script::generate_script`],
/// [`script::generate_script_with_filters`], and
/// [`script::generate_script_with_args`].
pub mod script;

/// Batch replay logic for applying recorded delta operations.
///
/// This module contains [`replay::replay`] for full batch-file replay and
/// [`replay::apply_delta_ops`] for applying individual delta operation
/// sequences to a file.
pub mod replay;

/// Batch file writer for recording transfers.
///
/// See [`BatchWriter`] for the main writer type.
pub mod writer;

#[cfg(test)]
mod tests;

/// Error type for batch operations.
///
/// See [`error::BatchError`] for detailed error variants.
pub use error::BatchError;

/// Result type alias for batch operations.
///
/// Equivalent to `Result<T, BatchError>`.
pub use error::BatchResult;

/// Bitmap of stream flags stored in batch file headers.
///
/// Encodes which rsync options were active when the batch was created
/// (e.g., recursion, preserve-uid, preserve-gid). These flags must match
/// when replaying the batch.
pub use format::BatchFlags;

/// Reconcile active options against a batch file's recorded stream flags.
///
/// Emits upstream's `--info=misc` reconcile notices and treats an `--iconv`
/// mismatch as fatal, mirroring `batch.c:check_batch_flags()`.
pub use format::check_batch_flags;

/// Binary header structure at the start of every batch file.
///
/// Contains protocol version, compatibility flags, checksum seed, and
/// stream flags. Used to validate batch file compatibility before replay.
pub use format::BatchHeader;

/// Transfer statistics recorded at the end of a batch file.
///
/// Contains total bytes read/written, total file size, and optional
/// file list timing information. Written using `varlong30` encoding
/// to match upstream rsync's `main.c` stats serialization.
pub use format::BatchStats;

/// File metadata for batch mode tracking.
///
/// Note: upstream rsync batch files use raw protocol stream bytes, not
/// custom file entry serialization. This type is for internal tracking.
pub use format::FileEntry;

/// Reader for replaying recorded batch files.
///
/// Opens an existing batch file and provides methods to read the header,
/// file list, and delta operations for applying to a destination.
pub use reader::BatchReader;

/// Writer for recording transfers to batch files.
///
/// Creates a new batch file and provides methods to write the header,
/// file list, and delta operations captured during a transfer.
pub use writer::BatchWriter;

/// Delta operation type re-exported from protocol for [`BatchReader::read_all_delta_ops`].
///
/// Delta operations represent the instructions for reconstructing a file
/// from a combination of existing data (copy operations) and new data
/// (literal operations).
pub use protocol::wire::DeltaOp;

/// Result of a batch replay operation containing aggregate statistics.
pub use replay::ReplayResult;

use std::path::Path;

/// Batch mode operation type.
///
/// Determines how the batch system behaves during a transfer operation.
/// This enum maps directly to the rsync command-line options:
///
/// - `--write-batch=FILE` maps to [`BatchMode::Write`]
/// - `--only-write-batch=FILE` maps to [`BatchMode::OnlyWrite`]
/// - `--read-batch=FILE` maps to [`BatchMode::Read`]
///
/// # Examples
///
/// ```
/// use batch::BatchMode;
///
/// let mode = BatchMode::Write;
/// assert!(matches!(mode, BatchMode::Write));
///
/// // BatchMode is Copy, so it can be used without cloning
/// let mode2 = mode;
/// assert_eq!(mode, mode2);
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BatchMode {
    /// Write batch file while performing transfer.
    ///
    /// This mode records the transfer operations to a batch file while
    /// simultaneously applying them to the destination. Use this when
    /// you want to both update the destination and create a batch for
    /// distributing the same changes elsewhere.
    ///
    /// Corresponds to `--write-batch=FILE` on the command line.
    Write,

    /// Write batch file without performing transfer.
    ///
    /// This mode only creates the batch file without modifying the
    /// destination. Useful for:
    /// - Creating batches without affecting production systems
    /// - Testing batch generation
    /// - Preparing updates in advance
    ///
    /// Corresponds to `--only-write-batch=FILE` on the command line.
    OnlyWrite,

    /// Read and replay batch file.
    ///
    /// This mode reads a previously created batch file and applies its
    /// recorded operations to the destination. The batch file must have
    /// been created with the same protocol version.
    ///
    /// Corresponds to `--read-batch=FILE` on the command line.
    Read,
}

/// Configuration for batch mode operations.
///
/// This struct holds all the configuration needed to read or write a batch
/// file. It encapsulates the batch mode, file paths, protocol version, and
/// other settings that affect batch file generation and parsing.
///
/// # Creating a Configuration
///
/// Use [`BatchConfig::new`] to create a basic configuration, then chain
/// builder methods to customize it:
///
/// ```
/// use batch::{BatchConfig, BatchMode};
///
/// let config = BatchConfig::new(
///     BatchMode::Write,
///     "/tmp/backup.batch".to_string(),
///     31,  // protocol version
/// )
/// .with_checksum_seed(42)
/// .with_compat_flags(0x01);
///
/// assert!(config.is_write_mode());
/// assert!(config.should_transfer());
/// ```
///
/// # File Paths
///
/// A batch operation creates two files:
/// - The binary batch file at `batch_path`
/// - A shell script at `batch_path.sh`
///
/// ```
/// use batch::{BatchConfig, BatchMode};
///
/// let config = BatchConfig::new(
///     BatchMode::Write,
///     "/tmp/mybatch".to_string(),
///     31,
/// );
///
/// assert_eq!(config.batch_file_path().to_str(), Some("/tmp/mybatch"));
/// assert_eq!(config.script_file_path(), "/tmp/mybatch.sh");
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BatchConfig {
    /// The batch mode operation type.
    ///
    /// Determines whether this configuration is for reading or writing
    /// a batch file, and whether actual file transfer should occur.
    pub mode: BatchMode,

    /// Path to the batch file (without .sh extension).
    ///
    /// This is the base path for the batch operation. The binary batch
    /// data is written to this path, and the shell script is written
    /// to `{batch_path}.sh`.
    pub batch_path: String,

    /// Protocol version being used.
    ///
    /// Must match between writer and reader. Protocol version affects
    /// which features are available (e.g., compat_flags requires >= 30).
    pub protocol_version: i32,

    /// Compatibility flags (protocol >= 30).
    ///
    /// These flags are automatically set based on protocol version in
    /// [`BatchConfig::new`]. For protocol versions < 30, this is `None`.
    pub compat_flags: Option<i32>,

    /// Checksum seed for the transfer.
    ///
    /// Used to initialize the rolling checksum algorithm. Must match
    /// between writer and reader for checksums to validate correctly.
    pub checksum_seed: i32,

    /// Binary name or path written to the replay script as the executable
    /// to invoke for `--read-batch`.
    ///
    /// Mirrors upstream rsync's `batch.c:259` which writes `raw_argv[0]`
    /// literally - the exact invocation path the user passed on the
    /// command line. Defaults to `"oc-rsync"` when not set, which only
    /// works if `oc-rsync` is resolvable on `PATH`. Callers that invoke
    /// the binary by absolute path (test harnesses, CI) should set this
    /// to the absolute path so the generated `BATCH.sh` runs without
    /// requiring `PATH` setup.
    pub invoker: String,

    /// The raw command-line argument vector (including `argv[0]`) of the
    /// original `--write-batch` invocation.
    ///
    /// Used to reconstruct the pass-through options in the replay script,
    /// mirroring upstream rsync's `raw_argv` in
    /// `batch.c:write_batch_shell_file()`. When empty, the script generator
    /// falls back to emitting only `--read-batch` without any transfer flags.
    pub replay_args: Vec<String>,

    /// The positional filename operands (sources and destination) of the
    /// original invocation.
    ///
    /// These are elided from the reconstructed replay command, mirroring how
    /// upstream nulls out the `cooked_argv` filename args
    /// (`batch.c:269-275`). The destination is re-supplied through the
    /// `${1:-<dest>}` placeholder instead.
    pub operands: Vec<String>,

    /// Data-stream-affecting options active during the current `--read-batch`
    /// invocation.
    ///
    /// Reconciled against the batch header's recorded stream flags by
    /// [`check_batch_flags`] when replaying, mirroring upstream
    /// `batch.c:check_batch_flags()`. Only consulted in read mode.
    pub active_flags: BatchFlags,

    /// Whether filter-rule terminators use NUL bytes instead of newlines.
    ///
    /// Set from `--from0` / `-0`. Controls how the `.sh` replay wrapper writes
    /// the filter heredoc: NUL-separated rules followed by a trailing `;\n`
    /// when true, matching upstream `batch.c:write_filter_rules()` under
    /// `eol_nulls`.
    pub eol_nulls: bool,
}

impl BatchConfig {
    /// Create a new batch configuration.
    ///
    /// Creates a configuration with default values for `compat_flags` and
    /// `checksum_seed`. Use the builder methods to customize these.
    ///
    /// # Arguments
    ///
    /// * `mode` - The batch operation mode (read, write, or only-write)
    /// * `batch_path` - Path to the batch file (without .sh extension)
    /// * `protocol_version` - The rsync protocol version to use
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// // Create a write configuration
    /// let write_config = BatchConfig::new(
    ///     BatchMode::Write,
    ///     "/tmp/backup".to_string(),
    ///     31,
    /// );
    ///
    /// // Create a read configuration
    /// let read_config = BatchConfig::new(
    ///     BatchMode::Read,
    ///     "/tmp/backup".to_string(),
    ///     31,
    /// );
    /// ```
    ///
    /// # Protocol Version Notes
    ///
    /// - Protocol >= 30: `compat_flags` is initialized to `Some(0)`
    /// - Protocol < 30: `compat_flags` is `None`
    pub fn new(mode: BatchMode, batch_path: String, protocol_version: i32) -> Self {
        Self {
            mode,
            batch_path,
            protocol_version,
            compat_flags: if protocol_version >= 30 {
                Some(0)
            } else {
                None
            },
            checksum_seed: 0,
            invoker: String::from("oc-rsync"),
            replay_args: Vec::new(),
            operands: Vec::new(),
            active_flags: BatchFlags::default(),
            eol_nulls: false,
        }
    }

    /// Set the compatibility flags.
    ///
    /// Compatibility flags control protocol-specific behavior. This is only
    /// applicable for protocol version 30 and above; for earlier versions,
    /// this method has no effect.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/batch".to_string(), 31)
    ///     .with_compat_flags(0x01);
    ///
    /// assert_eq!(config.compat_flags, Some(0x01));
    /// ```
    pub const fn with_compat_flags(mut self, flags: i32) -> Self {
        if self.protocol_version >= 30 {
            self.compat_flags = Some(flags);
        }
        self
    }

    /// Set the checksum seed.
    ///
    /// The checksum seed is used to initialize the rolling checksum algorithm
    /// during delta encoding. When replaying a batch, the same seed must be
    /// used to correctly verify file integrity.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/batch".to_string(), 31)
    ///     .with_checksum_seed(0xDEADBEEFu32 as i32);
    ///
    /// assert_eq!(config.checksum_seed, 0xDEADBEEFu32 as i32);
    /// ```
    pub const fn with_checksum_seed(mut self, seed: i32) -> Self {
        self.checksum_seed = seed;
        self
    }

    /// Set the binary name or path to embed in the replay shell script.
    ///
    /// Mirrors upstream rsync's `batch.c:259` which writes `raw_argv[0]`
    /// literally to the generated `BATCH.sh`. Pass the path the user
    /// originally invoked (`std::env::args_os().next()`) so the script
    /// runs without requiring `PATH` setup. When invoked by absolute
    /// path, this preserves that path; when invoked by bare name, the
    /// generated script also uses the bare name.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/batch".to_string(), 31)
    ///     .with_invoker("/usr/local/bin/oc-rsync");
    ///
    /// assert_eq!(config.invoker, "/usr/local/bin/oc-rsync");
    /// ```
    pub fn with_invoker(mut self, invoker: impl Into<String>) -> Self {
        self.invoker = invoker.into();
        self
    }

    /// Set the raw command-line arguments used to reconstruct the replay
    /// script's pass-through options.
    ///
    /// Pass the full argument vector including `argv[0]`
    /// (`std::env::args_os()`). The script generator elides the positional
    /// operands (see [`BatchConfig::with_operands`]) and converts
    /// `--write-batch` to `--read-batch`, mirroring upstream
    /// `batch.c:write_batch_shell_file()`.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/batch".to_string(), 31)
    ///     .with_replay_args(["oc-rsync", "-az", "--write-batch=/tmp/batch", "src/", "dst/"]);
    ///
    /// assert_eq!(config.replay_args.len(), 5);
    /// ```
    pub fn with_replay_args<I, S>(mut self, args: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.replay_args = args.into_iter().map(Into::into).collect();
        self
    }

    /// Set the positional filename operands that are elided from the replay
    /// command.
    ///
    /// These are the source and destination operands of the original
    /// invocation; the destination is re-supplied via the `${1:-<dest>}`
    /// placeholder. Mirrors upstream nulling of `cooked_argv` filenames
    /// (`batch.c:269-275`).
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/batch".to_string(), 31)
    ///     .with_operands(["src/", "dst/"]);
    ///
    /// assert_eq!(config.operands.len(), 2);
    /// ```
    pub fn with_operands<I, S>(mut self, operands: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.operands = operands.into_iter().map(Into::into).collect();
        self
    }

    /// Set the data-stream-affecting options active during `--read-batch`.
    ///
    /// These are reconciled against the batch header's recorded stream flags
    /// by [`check_batch_flags`] during replay. Mirrors upstream
    /// `batch.c:check_batch_flags()`.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchFlags, BatchMode};
    ///
    /// let flags = BatchFlags {
    ///     recurse: true,
    ///     ..BatchFlags::default()
    /// };
    /// let config = BatchConfig::new(BatchMode::Read, "/tmp/batch".to_string(), 31)
    ///     .with_active_flags(flags);
    ///
    /// assert!(config.active_flags.recurse);
    /// ```
    pub const fn with_active_flags(mut self, flags: BatchFlags) -> Self {
        self.active_flags = flags;
        self
    }

    /// Set whether filter-rule terminators use NUL bytes (`--from0` / `-0`).
    ///
    /// When `true`, the `.sh` replay wrapper writes NUL-separated filter rules
    /// followed by a trailing `;\n`, matching upstream
    /// `batch.c:write_filter_rules()` under `eol_nulls`.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/batch".to_string(), 31)
    ///     .with_eol_nulls(true);
    ///
    /// assert!(config.eol_nulls);
    /// ```
    pub const fn with_eol_nulls(mut self, eol_nulls: bool) -> Self {
        self.eol_nulls = eol_nulls;
        self
    }

    /// Get the path to the binary batch file.
    ///
    /// Returns the path where the binary batch data is stored. This is
    /// the same as `batch_path` but as a [`Path`] reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    /// use std::path::Path;
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/mybatch".to_string(), 31);
    /// assert_eq!(config.batch_file_path(), Path::new("/tmp/mybatch"));
    /// ```
    pub fn batch_file_path(&self) -> &Path {
        Path::new(&self.batch_path)
    }

    /// Get the path to the shell script file.
    ///
    /// Returns the path where the replay shell script is stored. This is
    /// always `{batch_path}.sh`.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let config = BatchConfig::new(BatchMode::Write, "/tmp/mybatch".to_string(), 31);
    /// assert_eq!(config.script_file_path(), "/tmp/mybatch.sh");
    /// ```
    pub fn script_file_path(&self) -> String {
        format!("{}.sh", self.batch_path)
    }

    /// Check if this is a write mode (Write or OnlyWrite).
    ///
    /// Returns `true` if the configuration is for writing a batch file,
    /// regardless of whether actual file transfer will occur.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let write = BatchConfig::new(BatchMode::Write, "/tmp/b".to_string(), 31);
    /// let only_write = BatchConfig::new(BatchMode::OnlyWrite, "/tmp/b".to_string(), 31);
    /// let read = BatchConfig::new(BatchMode::Read, "/tmp/b".to_string(), 31);
    ///
    /// assert!(write.is_write_mode());
    /// assert!(only_write.is_write_mode());
    /// assert!(!read.is_write_mode());
    /// ```
    pub const fn is_write_mode(&self) -> bool {
        matches!(self.mode, BatchMode::Write | BatchMode::OnlyWrite)
    }

    /// Check if this is read mode.
    ///
    /// Returns `true` if the configuration is for reading and replaying
    /// a batch file.
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let read = BatchConfig::new(BatchMode::Read, "/tmp/b".to_string(), 31);
    /// let write = BatchConfig::new(BatchMode::Write, "/tmp/b".to_string(), 31);
    ///
    /// assert!(read.is_read_mode());
    /// assert!(!write.is_read_mode());
    /// ```
    pub const fn is_read_mode(&self) -> bool {
        matches!(self.mode, BatchMode::Read)
    }

    /// Check if actual transfer should occur.
    ///
    /// Returns `true` if the batch mode involves actually transferring
    /// files to the destination. This is `true` for [`BatchMode::Write`]
    /// and [`BatchMode::Read`], but `false` for [`BatchMode::OnlyWrite`].
    ///
    /// # Examples
    ///
    /// ```
    /// use batch::{BatchConfig, BatchMode};
    ///
    /// let write = BatchConfig::new(BatchMode::Write, "/tmp/b".to_string(), 31);
    /// let only_write = BatchConfig::new(BatchMode::OnlyWrite, "/tmp/b".to_string(), 31);
    /// let read = BatchConfig::new(BatchMode::Read, "/tmp/b".to_string(), 31);
    ///
    /// assert!(write.should_transfer());      // Write mode transfers files
    /// assert!(!only_write.should_transfer()); // OnlyWrite just creates batch
    /// assert!(read.should_transfer());        // Read mode applies changes
    /// ```
    pub const fn should_transfer(&self) -> bool {
        !matches!(self.mode, BatchMode::OnlyWrite)
    }
}
