use digest::Digest;
use std::fmt;

use super::StrongDigest;
#[cfg(feature = "openssl")]
use super::openssl_support;

/// Seed configuration for MD5 checksum calculation.
///
/// Rsync uses seeded MD5 checksums for file list validation. The
/// `CHECKSUM_SEED_FIX` compatibility flag (protocol 30+) determines whether the
/// seed is hashed before or after the file data.
///
/// # Upstream Reference
///
/// - `checksum.c:get_checksum2()` - seed ordering logic
/// - `compat.c` - `CHECKSUM_SEED_FIX` negotiation
///
/// The flag controls:
///
/// - `proper_order = true` (new behavior): hash seed, then data
/// - `proper_order = false` (old behavior): hash data, then seed
///
/// This ordering difference affects checksum compatibility between protocol
/// versions.
///
/// # Examples
///
/// ```
/// use checksums::strong::{Md5, Md5Seed, StrongDigest};
///
/// // No seed (default behavior)
/// let unseeded = Md5::digest(b"data");
///
/// // Modern protocol (30+) with CHECKSUM_SEED_FIX: seed before data
/// let mut proper = Md5::with_seed(Md5Seed::proper(0x12345678));
/// proper.update(b"data");
/// let proper_digest = proper.finalize();
///
/// // Legacy protocol: seed after data
/// let mut legacy = Md5::with_seed(Md5Seed::legacy(0x12345678));
/// legacy.update(b"data");
/// let legacy_digest = legacy.finalize();
///
/// // All three produce different results
/// assert_ne!(unseeded, proper_digest);
/// assert_ne!(unseeded, legacy_digest);
/// assert_ne!(proper_digest, legacy_digest);
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Md5Seed {
    /// Seed value to mix into the hash, or `None` for standard unseeded MD5.
    ///
    /// Upstream rsync transmits the checksum seed as a 32-bit little-endian
    /// integer. The value is typically the transfer session ID.
    pub value: Option<i32>,
    /// Whether to hash the seed before the data (`true`) or after (`false`).
    ///
    /// Protocol 30+ with `CHECKSUM_SEED_FIX` uses proper ordering (seed first).
    /// Older protocols hash the seed after the data (legacy ordering).
    /// See upstream `checksum.c:get_checksum2()`.
    pub proper_order: bool,
}

impl Md5Seed {
    /// Creates a seed configuration with no seed value.
    ///
    /// # Examples
    ///
    /// ```
    /// use checksums::strong::{Md5, Md5Seed, StrongDigest};
    ///
    /// let mut hasher = Md5::with_seed(Md5Seed::none());
    /// hasher.update(b"test");
    /// let seeded = hasher.finalize();
    ///
    /// // Equivalent to unseeded hash
    /// assert_eq!(seeded, Md5::digest(b"test"));
    /// ```
    #[must_use]
    pub const fn none() -> Self {
        Self {
            value: None,
            proper_order: true,
        }
    }

    /// Creates a seed configuration with seed-before-data ordering (protocol 30+ with CHECKSUM_SEED_FIX).
    ///
    /// # Examples
    ///
    /// ```
    /// use checksums::strong::{Md5, Md5Seed, StrongDigest};
    ///
    /// let seed_value: i32 = 0x12345678;
    /// let mut hasher = Md5::with_seed(Md5Seed::proper(seed_value));
    /// hasher.update(b"file contents");
    /// let digest = hasher.finalize();
    ///
    /// // This is equivalent to: hash(seed_bytes || data)
    /// let mut manual = Md5::new();
    /// manual.update(&seed_value.to_le_bytes());
    /// manual.update(b"file contents");
    /// assert_eq!(digest, manual.finalize());
    /// ```
    #[must_use]
    pub const fn proper(value: i32) -> Self {
        Self {
            value: Some(value),
            proper_order: true,
        }
    }

    /// Creates a seed configuration with seed-after-data ordering (legacy protocols).
    ///
    /// # Examples
    ///
    /// ```
    /// use checksums::strong::{Md5, Md5Seed, StrongDigest};
    ///
    /// let seed_value: i32 = 0x12345678;
    /// let mut hasher = Md5::with_seed(Md5Seed::legacy(seed_value));
    /// hasher.update(b"file contents");
    /// let digest = hasher.finalize();
    ///
    /// // This is equivalent to: hash(data || seed_bytes)
    /// let mut manual = Md5::new();
    /// manual.update(b"file contents");
    /// manual.update(&seed_value.to_le_bytes());
    /// assert_eq!(digest, manual.finalize());
    /// ```
    #[must_use]
    pub const fn legacy(value: i32) -> Self {
        Self {
            value: Some(value),
            proper_order: false,
        }
    }
}

impl Default for Md5Seed {
    fn default() -> Self {
        Self::none()
    }
}

/// Streaming MD5 hasher used by rsync when backward compatibility demands it.
///
/// Supports optional seeded hashing with configurable ordering for protocol
/// compatibility. See [`Md5Seed`] for details on seed ordering behavior.
///
/// # Upstream Reference
///
/// - `checksum.c:get_checksum2()` - strong checksum computation (MD5 for protocol >= 30)
/// - `checksum.c:file_checksum()` - whole-file MD5 for file list validation
/// - `compat.c` - `CHECKSUM_SEED_FIX` controls seed ordering
///
/// # Examples
///
/// Basic one-shot hashing:
///
/// ```
/// use checksums::strong::Md5;
///
/// let digest = Md5::digest(b"hello world");
/// assert_eq!(digest.len(), 16); // MD5 produces 128-bit output
/// ```
///
/// Incremental hashing for large files:
///
/// ```
/// use checksums::strong::Md5;
///
/// let mut hasher = Md5::new();
///
/// // Process data in chunks (e.g., from a file)
/// hasher.update(b"chunk 1");
/// hasher.update(b"chunk 2");
/// hasher.update(b"chunk 3");
///
/// let digest = hasher.finalize();
/// assert_eq!(digest, Md5::digest(b"chunk 1chunk 2chunk 3"));
/// ```
///
/// Seeded hashing for rsync protocol compatibility:
///
/// ```
/// use checksums::strong::{Md5, Md5Seed, StrongDigest};
///
/// // Protocol 30+ uses seed-before-data ordering
/// let mut hasher = Md5::with_seed(Md5Seed::proper(0x12345678));
/// hasher.update(b"file data");
/// let digest = hasher.finalize();
/// ```
///
/// Verifying data integrity:
///
/// ```
/// use checksums::strong::Md5;
///
/// fn verify_checksum(data: &[u8], expected: &[u8; 16]) -> bool {
///     Md5::digest(data) == *expected
/// }
///
/// let data = b"important data";
/// let checksum = Md5::digest(data);
///
/// assert!(verify_checksum(data, &checksum));
/// assert!(!verify_checksum(b"tampered data", &checksum));
/// ```
#[derive(Clone)]
pub struct Md5 {
    inner: Md5Backend,
    /// Deferred seed for legacy (pre-CHECKSUM_SEED_FIX) ordering.
    pending_seed: Option<i32>,
}

#[derive(Clone)]
enum Md5Backend {
    #[cfg(feature = "openssl")]
    OpenSsl(openssl::hash::Hasher),
    Rust(md5::Md5),
}

impl Md5Backend {
    fn new() -> Self {
        #[cfg(feature = "openssl")]
        {
            if let Some(hasher) = openssl_support::new_md5_hasher() {
                return Self::OpenSsl(hasher);
            }
        }

        Self::Rust(md5::Md5::new())
    }
}

impl fmt::Debug for Md5 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Md5").field("backend", &self.inner).finish()
    }
}

impl fmt::Debug for Md5Backend {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            #[cfg(feature = "openssl")]
            Md5Backend::OpenSsl(_) => f.write_str("OpenSsl"),
            Md5Backend::Rust(_) => f.write_str("Rust"),
        }
    }
}

impl Default for Md5 {
    fn default() -> Self {
        Self::new()
    }
}

impl Md5 {
    /// Creates a hasher with an empty state and no seed.
    ///
    /// # Examples
    ///
    /// ```
    /// use checksums::strong::Md5;
    ///
    /// let mut hasher = Md5::new();
    /// hasher.update(b"data");
    /// let digest = hasher.finalize();
    /// assert_eq!(digest.len(), 16);
    /// ```
    #[must_use]
    pub fn new() -> Self {
        Self {
            inner: Md5Backend::new(),
            pending_seed: None,
        }
    }

    /// Feeds additional bytes into the digest state.
    ///
    /// # Examples
    ///
    /// ```
    /// use checksums::strong::Md5;
    ///
    /// let mut hasher = Md5::new();
    ///
    /// // Multiple updates are concatenated
    /// hasher.update(b"hello");
    /// hasher.update(b" ");
    /// hasher.update(b"world");
    ///
    /// // Same as hashing "hello world" at once
    /// assert_eq!(hasher.finalize(), Md5::digest(b"hello world"));
    /// ```
    pub fn update(&mut self, data: &[u8]) {
        match &mut self.inner {
            #[cfg(feature = "openssl")]
            Md5Backend::OpenSsl(hasher) => {
                hasher.update(data).expect("OpenSSL MD5 update failed");
            }
            Md5Backend::Rust(hasher) => hasher.update(data),
        }
    }

    /// Finalises the digest and returns the 128-bit MD5 output.
    ///
    /// If a seed was configured with `proper_order = false` (legacy ordering),
    /// the seed bytes are hashed after the data before finalizing.
    ///
    /// # Examples
    ///
    /// ```
    /// use checksums::strong::Md5;
    ///
    /// let mut hasher = Md5::new();
    /// hasher.update(b"data");
    /// let digest = hasher.finalize();
    ///
    /// // Hasher is consumed; use clone for intermediate results
    /// let mut h1 = Md5::new();
    /// h1.update(b"prefix");
    /// let prefix_hash = h1.clone().finalize();
    ///
    /// h1.update(b"suffix");
    /// let full_hash = h1.finalize();
    ///
    /// assert_ne!(prefix_hash, full_hash);
    /// ```
    #[must_use]
    pub fn finalize(mut self) -> [u8; 16] {
        // upstream: checksum.c:get_checksum2() - legacy seed ordering
        if let Some(seed) = self.pending_seed {
            self.update(&seed.to_le_bytes());
        }

        match self.inner {
            #[cfg(feature = "openssl")]
            Md5Backend::OpenSsl(mut hasher) => {
                let mut output = [0_u8; 16];
                let bytes = hasher.finish().expect("OpenSSL MD5 finalisation failed");
                output.copy_from_slice(bytes.as_ref());
                output
            }
            Md5Backend::Rust(hasher) => hasher.finalize().into(),
        }
    }

    /// Convenience helper that computes the MD5 digest for `data` in one shot.
    ///
    /// # Examples
    ///
    /// ```
    /// use checksums::strong::Md5;
    ///
    /// // Compute hash of a message
    /// let digest = Md5::digest(b"The quick brown fox");
    /// assert_eq!(digest.len(), 16);
    ///
    /// // Same input always produces same output
    /// assert_eq!(Md5::digest(b"test"), Md5::digest(b"test"));
    ///
    /// // Different input produces different output
    /// assert_ne!(Md5::digest(b"test1"), Md5::digest(b"test2"));
    /// ```
    #[must_use]
    pub fn digest(data: &[u8]) -> [u8; 16] {
        <Self as StrongDigest>::digest(data)
    }
}

impl StrongDigest for Md5 {
    type Seed = Md5Seed;
    type Digest = [u8; 16];
    const DIGEST_LEN: usize = 16;

    fn with_seed(seed: Self::Seed) -> Self {
        let mut md5 = Self {
            inner: Md5Backend::new(),
            pending_seed: None,
        };

        if let Some(value) = seed.value {
            if seed.proper_order {
                // upstream: checksum.c:get_checksum2() - CHECKSUM_SEED_FIX (protocol 30+)
                md5.update(&value.to_le_bytes());
            } else {
                // upstream: checksum.c:get_checksum2() - pre-CHECKSUM_SEED_FIX ordering
                md5.pending_seed = Some(value);
            }
        }

        md5
    }

    fn update(&mut self, data: &[u8]) {
        self.update(data);
    }

    fn finalize(mut self) -> Self::Digest {
        // upstream: checksum.c:get_checksum2() - legacy seed ordering
        if let Some(seed) = self.pending_seed {
            self.update(&seed.to_le_bytes());
        }

        match self.inner {
            #[cfg(feature = "openssl")]
            Md5Backend::OpenSsl(mut hasher) => {
                let mut output = [0_u8; 16];
                let bytes = hasher.finish().expect("OpenSSL MD5 finalisation failed");
                output.copy_from_slice(bytes.as_ref());
                output
            }
            Md5Backend::Rust(hasher) => hasher.finalize().into(),
        }
    }
}

/// Batch compute MD5 digests using SIMD when available.
///
/// This function computes MD5 digests for multiple inputs in parallel using
/// SIMD instructions (AVX2/AVX-512/NEON) via runtime CPUID detection.
/// Falls back to scalar computation when no SIMD instructions are available.
///
/// All implementations maintain RFC 1321 compatibility.
///
/// # Examples
///
/// ```
/// use checksums::strong::md5_digest_batch;
///
/// let inputs = [b"block1".as_slice(), b"block2", b"block3"];
/// let digests = md5_digest_batch(&inputs);
///
/// assert_eq!(digests.len(), 3);
/// for digest in &digests {
///     assert_eq!(digest.len(), 16);
/// }
/// ```
pub fn digest_batch<T: AsRef<[u8]>>(inputs: &[T]) -> Vec<[u8; 16]> {
    crate::simd_batch::digest_batch(inputs)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn to_hex(bytes: &[u8]) -> String {
        use std::fmt::Write as _;

        let mut out = String::with_capacity(bytes.len() * 2);
        for byte in bytes {
            write!(&mut out, "{byte:02x}").expect("write! to String cannot fail");
        }
        out
    }

    #[test]
    fn md5_streaming_matches_rfc_vectors() {
        let vectors = [
            (b"".as_slice(), "d41d8cd98f00b204e9800998ecf8427e"),
            (b"a".as_slice(), "0cc175b9c0f1b6a831c399e269772661"),
            (b"abc".as_slice(), "900150983cd24fb0d6963f7d28e17f72"),
            (
                b"message digest".as_slice(),
                "f96b697d7cb7938d525a2f31aaf161d0",
            ),
        ];

        for (input, expected_hex) in vectors {
            let mut hasher = Md5::new();
            let mid = input.len() / 2;
            hasher.update(&input[..mid]);
            hasher.update(&input[mid..]);
            let digest = hasher.finalize();
            assert_eq!(to_hex(&digest), expected_hex);

            let one_shot = Md5::digest(input);
            assert_eq!(to_hex(&one_shot), expected_hex);
        }
    }

    #[test]
    fn md5_seeded_proper_order_hashes_seed_before_data() {
        let seed_value: i32 = 0x12345678;
        let data = b"test data";

        let mut with_seed = Md5::with_seed(Md5Seed::proper(seed_value));
        with_seed.update(data);
        let seeded_digest = with_seed.finalize();

        let mut manual = Md5::new();
        manual.update(&seed_value.to_le_bytes());
        manual.update(data);
        let manual_digest = manual.finalize();

        assert_eq!(
            to_hex(&seeded_digest),
            to_hex(&manual_digest),
            "Proper order should hash seed before data"
        );

        let unseeded_digest = Md5::digest(data);
        assert_ne!(
            to_hex(&seeded_digest),
            to_hex(&unseeded_digest),
            "Seeded hash should differ from unseeded"
        );
    }

    #[test]
    fn md5_seeded_legacy_order_hashes_seed_after_data() {
        let seed_value: i32 = 0x12345678;
        let data = b"test data";

        let mut with_seed = Md5::with_seed(Md5Seed::legacy(seed_value));
        with_seed.update(data);
        let seeded_digest = with_seed.finalize();

        let mut manual = Md5::new();
        manual.update(data);
        manual.update(&seed_value.to_le_bytes());
        let manual_digest = manual.finalize();

        assert_eq!(
            to_hex(&seeded_digest),
            to_hex(&manual_digest),
            "Legacy order should hash seed after data"
        );
    }

    #[test]
    fn md5_seed_ordering_produces_different_hashes() {
        let seed_value: i32 = 0x1BCDEF01u32 as i32;
        let data = b"same data for both";

        let mut proper = Md5::with_seed(Md5Seed::proper(seed_value));
        proper.update(data);
        let proper_digest = proper.finalize();

        let mut legacy = Md5::with_seed(Md5Seed::legacy(seed_value));
        legacy.update(data);
        let legacy_digest = legacy.finalize();

        assert_ne!(
            to_hex(&proper_digest),
            to_hex(&legacy_digest),
            "Proper and legacy order should produce different hashes"
        );
    }

    #[test]
    fn md5_no_seed_matches_unseeded_hash() {
        let data = b"unseeded test";

        let mut with_none_seed = Md5::with_seed(Md5Seed::none());
        with_none_seed.update(data);
        let none_seeded = with_none_seed.finalize();

        let unseeded = Md5::digest(data);

        assert_eq!(
            to_hex(&none_seeded),
            to_hex(&unseeded),
            "Md5Seed::none() should match unseeded hash"
        );
    }

    #[test]
    fn md5_default_seed_is_none() {
        let data = b"default test";

        let mut with_default = Md5::with_seed(Md5Seed::default());
        with_default.update(data);
        let default_digest = with_default.finalize();

        let unseeded = Md5::digest(data);

        assert_eq!(
            to_hex(&default_digest),
            to_hex(&unseeded),
            "Default seed should match unseeded hash"
        );
    }

    #[test]
    fn md5_batch_matches_sequential() {
        let inputs: &[&[u8]] = &[
            b"",
            b"a",
            b"abc",
            b"message digest",
            b"abcdefghijklmnopqrstuvwxyz",
        ];

        let batch_results = super::digest_batch(inputs);
        let sequential_results: Vec<[u8; 16]> = inputs.iter().map(|i| Md5::digest(i)).collect();

        assert_eq!(batch_results.len(), sequential_results.len());
        for (i, (batch, seq)) in batch_results
            .iter()
            .zip(sequential_results.iter())
            .enumerate()
        {
            assert_eq!(to_hex(batch), to_hex(seq), "Mismatch at index {i}");
        }
    }

    // CSM-8 parity: when the OpenSSL backend is the default-selected backend on
    // Unix (G1), every digest must be byte-identical to the pure-Rust `md-5`
    // crate output for the same input. The active backend is dictated by the
    // build configuration; the reference value is computed from the
    // pure-Rust crate directly to keep the comparison independent of which
    // backend `Md5::new()` happens to pick.
    #[test]
    fn md5_active_backend_matches_pure_rust_reference() {
        let inputs: &[&[u8]] = &[
            b"",
            b"a",
            b"abc",
            b"message digest",
            b"abcdefghijklmnopqrstuvwxyz",
            b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
            // span the 64-byte MD5 block boundary deterministically
            &[0xAB_u8; 63],
            &[0xCD_u8; 64],
            &[0xEF_u8; 65],
            &[0x5A_u8; 1024],
        ];

        for (i, input) in inputs.iter().enumerate() {
            let active = Md5::digest(input);

            let mut reference = md5::Md5::new();
            reference.update(input);
            let reference: [u8; 16] = reference.finalize().into();

            assert_eq!(
                to_hex(&active),
                to_hex(&reference),
                "backend digest diverged from md-5 reference at input #{i}"
            );
        }
    }

    // CSM-8 parity: seeded hashing must also match upstream byte-for-byte
    // regardless of backend selection. Covers the proper (protocol >= 30) and
    // legacy (pre-CHECKSUM_SEED_FIX) seed orderings.
    #[test]
    fn md5_active_backend_matches_pure_rust_reference_seeded() {
        let seed_value: i32 = 0x12345678;
        let payloads: &[&[u8]] = &[b"", b"abc", b"message digest", &[0xAA_u8; 4096]];

        for (i, data) in payloads.iter().enumerate() {
            // proper order: seed bytes hashed before data
            let mut proper = <Md5 as StrongDigest>::with_seed(Md5Seed::proper(seed_value));
            proper.update(data);
            let proper = proper.finalize();

            let mut proper_ref = md5::Md5::new();
            proper_ref.update(seed_value.to_le_bytes());
            proper_ref.update(data);
            let proper_ref: [u8; 16] = proper_ref.finalize().into();

            assert_eq!(
                to_hex(&proper),
                to_hex(&proper_ref),
                "proper-order seeded MD5 diverged at input #{i}"
            );

            // legacy order: seed bytes hashed after data
            let mut legacy = <Md5 as StrongDigest>::with_seed(Md5Seed::legacy(seed_value));
            legacy.update(data);
            let legacy = legacy.finalize();

            let mut legacy_ref = md5::Md5::new();
            legacy_ref.update(data);
            legacy_ref.update(seed_value.to_le_bytes());
            let legacy_ref: [u8; 16] = legacy_ref.finalize().into();

            assert_eq!(
                to_hex(&legacy),
                to_hex(&legacy_ref),
                "legacy-order seeded MD5 diverged at input #{i}"
            );
        }
    }
}
