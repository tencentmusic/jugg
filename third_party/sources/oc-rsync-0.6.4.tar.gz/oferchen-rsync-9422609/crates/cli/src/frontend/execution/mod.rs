mod chown;
mod compression;
mod drive;
mod file_list;
mod flags;
mod module_list;
mod operands;
mod options;
mod stop;

pub(super) use drive::execute;

#[cfg(test)]
use super::arguments::ProgramName;
pub(crate) use chown::parse_chown_argument;
pub(crate) use compression::{
    CompressChoice, CompressLevelArg, parse_bandwidth_limit, parse_compress_choice,
    parse_compress_level, parse_compress_level_argument, parse_compress_threads,
};
#[cfg(test)]
pub(crate) use drive::CONNECT_PROGRAM_DAEMON_ONLY_MESSAGE;
#[cfg(test)]
pub(crate) use file_list::read_file_list_from_reader;
pub(crate) use file_list::{
    load_file_list_operands, operand_is_remote, resolve_file_list_entries,
    resolve_files_from_source,
};
pub(crate) use flags::{
    DEBUG_HELP_TEXT, INFO_HELP_TEXT, parse_debug_flags, parse_info_flags, parse_info_flags_server,
};
pub(crate) use module_list::render_module_list;
pub(crate) use operands::{extract_operands, parse_bind_address_argument};
pub(crate) use options::{
    ProtocolArg, legacy_remote_rejection, parse_block_size_argument, parse_checksum_seed_argument,
    parse_max_alloc_argument, parse_max_delete_argument, parse_modify_window_argument,
    parse_protocol_version_arg, parse_size_limit_argument, parse_timeout_argument,
    resolve_iconv_setting,
};
pub(crate) use stop::{parse_stop_after_argument, parse_stop_at_argument};

#[cfg(test)]
pub(crate) fn render_missing_operands_stdout(program_name: ProgramName) -> String {
    drive::render_missing_operands_stdout(program_name)
}
