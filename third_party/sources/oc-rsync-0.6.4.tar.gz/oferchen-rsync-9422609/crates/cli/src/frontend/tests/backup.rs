use super::common::*;
use super::*;

#[test]
fn backup_flag_creates_default_suffix_backups() {
    use tempfile::tempdir;

    let tmp = tempdir().expect("tempdir");
    let source_dir = tmp.path().join("source");
    let dest_dir = tmp.path().join("dest");
    std::fs::create_dir_all(&source_dir).expect("create source dir");
    std::fs::create_dir_all(&dest_dir).expect("create dest dir");

    let source_file = source_dir.join("file.txt");
    std::fs::write(&source_file, b"new data").expect("write source");

    let dest_root = dest_dir.join("source");
    std::fs::create_dir_all(&dest_root).expect("create dest root");
    std::fs::write(dest_root.join("file.txt"), b"old data").expect("seed dest");
    // Backdate destination to prevent quick-check skip (same size files)
    let one_hour_ago = filetime::FileTime::from_system_time(
        std::time::SystemTime::now() - std::time::Duration::from_secs(3600),
    );
    filetime::set_file_mtime(dest_root.join("file.txt"), one_hour_ago).expect("backdate dest");

    let (code, stdout, stderr) = run_with_args([
        OsString::from(RSYNC),
        OsString::from("-r"),
        OsString::from("--backup"),
        source_dir.into_os_string(),
        dest_dir.clone().into_os_string(),
    ]);

    assert_eq!(code, 0);
    assert!(stdout.is_empty());
    assert!(stderr.is_empty());

    let target_root = dest_dir.join("source");
    assert_eq!(
        std::fs::read(target_root.join("file.txt")).expect("read dest"),
        b"new data"
    );
    assert_eq!(
        std::fs::read(target_root.join("file.txt~")).expect("read backup"),
        b"old data"
    );
}

#[test]
fn backup_dir_flag_places_backups_in_relative_directory() {
    use tempfile::tempdir;

    let tmp = tempdir().expect("tempdir");
    let source_dir = tmp.path().join("source");
    let dest_dir = tmp.path().join("dest");
    std::fs::create_dir_all(source_dir.join("nested")).expect("create nested source");
    std::fs::create_dir_all(dest_dir.join("source/nested")).expect("create nested dest");

    let source_file = source_dir.join("nested/file.txt");
    std::fs::write(&source_file, b"updated").expect("write source");
    std::fs::write(dest_dir.join("source/nested/file.txt"), b"previous").expect("seed dest");
    // Backdate destination to prevent quick-check skip (same mtime+size = no transfer)
    let one_hour_ago = filetime::FileTime::from_system_time(
        std::time::SystemTime::now() - std::time::Duration::from_secs(3600),
    );
    filetime::set_file_mtime(dest_dir.join("source/nested/file.txt"), one_hour_ago)
        .expect("backdate dest");

    let (code, stdout, stderr) = run_with_args([
        OsString::from(RSYNC),
        OsString::from("-r"),
        OsString::from("--backup-dir"),
        OsString::from("backups"),
        OsString::from("--suffix"),
        OsString::from(""),
        source_dir.into_os_string(),
        dest_dir.clone().into_os_string(),
    ]);

    assert_eq!(code, 0);
    assert!(stdout.is_empty());
    assert!(stderr.is_empty());

    // upstream: options.c:2296-2297 - --backup-dir without --suffix defaults the
    // suffix to "" (empty). This test pins the empty-suffix layout explicitly via
    // `--suffix ''` so the assertion exercises the upstream rule directly without
    // depending on the implicit default. See also
    // `crates/engine/src/local_copy/tests/backups.rs::backup_dir_with_inplace_no_whole_file_copies_matched_blocks`
    // (PR #5916) which mirrors the same upstream rule on the engine builder.
    let backup_path = dest_dir.join("backups/source/nested/file.txt");
    assert_eq!(
        std::fs::read(&backup_path).expect("read backup"),
        b"previous"
    );
    assert_eq!(
        std::fs::read(dest_dir.join("source/nested/file.txt")).expect("read dest"),
        b"updated"
    );
}

#[test]
fn backup_suffix_flag_overrides_default_suffix() {
    use tempfile::tempdir;

    let tmp = tempdir().expect("tempdir");
    let source_dir = tmp.path().join("source");
    let dest_dir = tmp.path().join("dest");
    std::fs::create_dir_all(&source_dir).expect("create source dir");
    std::fs::create_dir_all(&dest_dir).expect("create dest dir");

    let source_file = source_dir.join("file.txt");
    std::fs::write(&source_file, b"fresh").expect("write source");
    let dest_root = dest_dir.join("source");
    std::fs::create_dir_all(&dest_root).expect("create dest root");
    std::fs::write(dest_root.join("file.txt"), b"stale").expect("seed dest");
    // Backdate destination to prevent quick-check skip (same size files)
    let one_hour_ago = filetime::FileTime::from_system_time(
        std::time::SystemTime::now() - std::time::Duration::from_secs(3600),
    );
    filetime::set_file_mtime(dest_root.join("file.txt"), one_hour_ago).expect("backdate dest");

    // upstream: options.c:2296-2307 - `--suffix` sets the suffix string but does
    // NOT enable backups on its own; `--backup` must be given explicitly.
    let (code, stdout, stderr) = run_with_args([
        OsString::from(RSYNC),
        OsString::from("-r"),
        OsString::from("--backup"),
        OsString::from("--suffix"),
        OsString::from(".bak"),
        source_dir.into_os_string(),
        dest_dir.into_os_string(),
    ]);

    assert_eq!(code, 0);
    assert!(stdout.is_empty());
    assert!(stderr.is_empty());

    assert_eq!(
        std::fs::read(dest_root.join("file.txt")).expect("read dest"),
        b"fresh"
    );
    let backup_path = dest_root.join("file.txt.bak");
    assert_eq!(std::fs::read(&backup_path).expect("read backup"), b"stale");
}
