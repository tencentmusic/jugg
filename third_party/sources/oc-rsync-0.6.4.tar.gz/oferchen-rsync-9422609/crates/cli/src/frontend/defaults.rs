//! Constants shared across the CLI front-end.

use time::{format_description::FormatItem, macros::format_description};

/// Comma-separated description of the options currently recognised by the CLI help text.
pub(super) const SUPPORTED_OPTIONS_LIST: &str = concat!(
    "--help, --version/-V, -e/--rsh, --rsync-path, --connect-program, --port, --address, ",
    "--remote-option/-M, --protect-args/-s, --no-protect-args, --secluded-args, --no-secluded-args, ",
    "--ipv4, --ipv6, --daemon, --config, --dry-run/-n, --list-only, --archive/-a, --recursive/-r, --no-recursive, ",
    "--dirs/-d, --no-dirs, --delete/--del, --delete-before, --delete-during, --delete-delay, --delete-after, ",
    "--delete-excluded, --max-delete, --min-size, --max-size, --max-alloc, --block-size, --backup/-b, --backup-dir, ",
    "--suffix, --checksum/-c, --checksum-choice, --checksum-seed, --size-only, --ignore-times, --ignore-existing, --existing, ",
    "--ignore-missing-args, --delete-missing-args, --update/-u, --modify-window, --exclude, --exclude-from, ",
    "--include, --include-from, --compare-dest, --copy-dest, --link-dest, --hard-links/-H, --no-hard-links, ",
    "--cvs-exclude/-C, --apple-double-skip, --filter/-F (including exclude-if-present=FILE), --files-from, --password-file, --password-command, --no-motd, ",
    "--from0, --no-from0, --bwlimit, --no-bwlimit, --timeout, --contimeout, --stop-after/--time-limit, --stop-at, --sockopts, ",
    "--tcp-fastopen, --blocking-io, --no-blocking-io, --protocol, --compress/-z, --no-compress, --compress-level, --compress-choice, --compress-threads, ",
    "--skip-compress, --open-noatime, --no-open-noatime, --iconv, --no-iconv, --info, --debug, --verbose/-v, --no-verbose, ",
    "--relative/-R, --no-relative, --one-file-system/-x, --no-one-file-system, --implied-dirs, --no-implied-dirs, ",
    "--mkpath, --no-mkpath, --old-dirs/--old-d, --prune-empty-dirs/-m, --no-prune-empty-dirs, --progress, --no-progress, --quiet, --no-quiet, ",
    "--force, --no-force, --fuzzy/-y, --no-fuzzy, --msgs2stderr, --no-msgs2stderr, --8-bit-output, --outbuf, ",
    "--itemize-changes/-i, --no-itemize-changes, --out-format, --stats, --partial, --no-partial, --partial-dir, --temp-dir, --log-file, ",
    "--log-file-format, --delay-updates, --no-delay-updates, --whole-file/-W, --no-whole-file, --xxh64-dedup, --remove-source-files, ",
    "--remove-sent-files, --append, --no-append, --append-verify, --preallocate, --fsync, --io-uring, --no-io-uring, --no-io-uring-sqpoll, --io-uring-depth, --io-uring-status, --lsm-status, --simd, --cow, --no-cow, --reflink, --zero-copy, --no-zero-copy, --parallel-delta-scan, --inplace, --no-inplace, ",
    "--human-readable/-h, --no-human-readable, -P, --sparse/-S, --no-sparse/--no-S, --sparse-detect, --links/-l, --no-links/--no-l, ",
    "--copy-links/-L, ",
    "--copy-unsafe-links, --safe-links, --copy-dirlinks/-k, --keep-dirlinks/-K, ",
    "-D, --devices, --copy-devices, --no-devices, --specials, --no-specials, --super, --no-super, --owner, --no-owner, --group, --no-group, ",
    "--chown, --usermap, --groupmap, --chmod, --executability/-E, --perms/-p, --no-perms, --times/-t, --no-times, ",
    "--atimes/-U, --no-atimes, --crtimes/-N, --no-crtimes, --omit-dir-times, --no-omit-dir-times, --omit-link-times, --no-omit-link-times, ",
    "--acls/-A, --no-acls, --xattrs/-X, --no-xattrs, ",
    "--numeric-ids, --no-numeric-ids, --rayon-threads, --checksum-threads, --tokio-threads"
);

/// Format string used for `--itemize-changes` output.
pub(super) const ITEMIZE_CHANGES_FORMAT: &str = "%i %n%L";

/// Default patterns excluded by `--cvs-exclude`.
///
/// Re-exported from the `filters` crate so there is a single canonical
/// definition of the built-in CVS-ignore list (see [`filters::DEFAULT_CVSIGNORE`]).
pub(super) use filters::DEFAULT_CVSIGNORE as CVS_EXCLUDE_PATTERNS;

/// Default patterns excluded by `--apple-double-skip` (macOS AppleDouble sidecars).
///
/// These files (`._foo`) carry FinderInfo, resource forks, and extended
/// attributes for files on filesystems that cannot represent them natively.
/// They are rarely useful when transferred to other systems and clutter
/// destinations.
pub(super) const APPLE_DOUBLE_EXCLUDE_PATTERNS: &[&str] = &["._*"];

/// Timestamp format used for `--list-only` and `--out-format` placeholders.
pub(crate) const LIST_TIMESTAMP_FORMAT: &[FormatItem<'static>] = format_description!(
    "[year]/[month padding:zero]/[day padding:zero] [hour padding:zero]:[minute padding:zero]:[second padding:zero]"
);

#[cfg(test)]
#[allow(clippy::const_is_empty)]
mod tests {
    use super::*;

    #[test]
    fn supported_options_list_not_empty() {
        assert!(!SUPPORTED_OPTIONS_LIST.is_empty());
    }

    #[test]
    fn supported_options_list_contains_help() {
        assert!(SUPPORTED_OPTIONS_LIST.contains("--help"));
    }

    #[test]
    fn supported_options_list_contains_archive() {
        assert!(SUPPORTED_OPTIONS_LIST.contains("--archive"));
    }

    #[test]
    fn itemize_changes_format_valid() {
        assert!(ITEMIZE_CHANGES_FORMAT.contains("%i"));
        assert!(ITEMIZE_CHANGES_FORMAT.contains("%n"));
    }

    #[test]
    fn cvs_exclude_patterns_not_empty() {
        assert!(!CVS_EXCLUDE_PATTERNS.is_empty());
    }

    #[test]
    fn cvs_exclude_patterns_contains_git() {
        assert!(CVS_EXCLUDE_PATTERNS.contains(&".git/"));
    }

    #[test]
    fn cvs_exclude_patterns_contains_svn() {
        assert!(CVS_EXCLUDE_PATTERNS.contains(&".svn/"));
    }

    #[test]
    fn cvs_exclude_patterns_contains_object_files() {
        assert!(CVS_EXCLUDE_PATTERNS.contains(&"*.o"));
        assert!(CVS_EXCLUDE_PATTERNS.contains(&"*.obj"));
    }

    #[test]
    fn list_timestamp_format_not_empty() {
        assert!(!LIST_TIMESTAMP_FORMAT.is_empty());
    }

    #[test]
    fn apple_double_exclude_patterns_not_empty() {
        assert!(!APPLE_DOUBLE_EXCLUDE_PATTERNS.is_empty());
    }

    #[test]
    fn apple_double_exclude_patterns_contains_dot_underscore() {
        assert!(APPLE_DOUBLE_EXCLUDE_PATTERNS.contains(&"._*"));
    }

    #[test]
    fn supported_options_list_contains_apple_double_skip() {
        assert!(SUPPORTED_OPTIONS_LIST.contains("--apple-double-skip"));
    }

    #[test]
    fn supported_options_list_contains_zero_copy() {
        assert!(SUPPORTED_OPTIONS_LIST.contains("--zero-copy"));
        assert!(SUPPORTED_OPTIONS_LIST.contains("--no-zero-copy"));
    }
}
